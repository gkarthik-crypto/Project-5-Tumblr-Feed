//
//  PostTableViewCell.swift
//  ios101-project5-tumblr
//
//  Created by Andros Slowley on 3/11/26.
//

import UIKit

class PostTableViewCell: UITableViewCell {
    @IBOutlet weak var photo: UIImageView!
    
    @IBOutlet weak var postDiscription: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
