//
//  ViewController.swift
//  ios101-project5-tumbler
//

import UIKit
import Nuke

class ViewController: UIViewController, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      let cell = tableView.dequeueReusableCell(withIdentifier: "postID", for: indexPath) as! PostTableViewCell
         let post = posts[indexPath.row]
        cell.postDiscription.text = post.summary
        if let photo = post.photos.first {
            let url = photo.originalSize.url
            ImagePipeline.shared.loadImage(with: url) { result in
                switch result {
                case .success(let response):
                    DispatchQueue.main.async {
                        cell.photo.image = response.image
                    }
                case .failure:
                    DispatchQueue.main.async {
                        cell.photo.image = nil
                    }
                }
            }
        } else {
            cell.photo.image = nil
        }

        return cell
        
    }
        
    
    
  

    @IBOutlet weak var postTableView: UITableView!
    var posts: [Post] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        postTableView.dataSource = self
        postTableView.rowHeight = UITableView.automaticDimension
        postTableView.estimatedRowHeight = 200
        let nib = UINib(nibName: "PostTableViewCell", bundle:nil)
        postTableView.register(nib, forCellReuseIdentifier:"postID")
        fetchPosts()
    }

    func fetchPosts() {
        let url = URL(string: "https://api.tumblr.com/v2/blog/humansofnewyork/posts/photo?api_key=1zT8CiXGXFcQDyMFG7RtcfGLwTdDjFUJnZzKJaWTmgyK4lKGYk")!
        let session = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("❌ Error: \(error.localizedDescription)")
                return
            }

            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, (200...299).contains(statusCode) else {
                print("❌ Response error: \(String(describing: response))")
                return
            }

            guard let data = data else {
                print("❌ Data is NIL")
                return
            }

            do {
                let blog = try JSONDecoder().decode(Blog.self, from: data)

                DispatchQueue.main.async { [weak self] in

                    let posts = blog.response.posts
                    self?.posts = posts
                    self?.postTableView.reloadData()
                    print("✅ We got \(posts.count) posts!")
                    for post in posts {
                        print("🍏 Summary: \(post.summary)")
                    }
                }

            } catch {
                print("❌ Error decoding JSON: \(error.localizedDescription)")
            }
        }
        session.resume()
    
    }
}

